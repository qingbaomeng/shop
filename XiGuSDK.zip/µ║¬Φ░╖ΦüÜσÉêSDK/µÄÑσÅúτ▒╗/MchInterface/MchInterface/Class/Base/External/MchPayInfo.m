//
//  MchPayInfo.m
//  MchInterface
//
//  Created by zhujin on 2017/7/31.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import "MchPayInfo.h"

@implementation MchPayInfo

- (id)init{
    if(self = [super init]){
        self.goodsName  = @"";
        self.goodsPrice = @"";
        self.productId  = @"";
        self.extendInfo = @"";
        self.orderString = @"";
    }
    return self;
}

@end


