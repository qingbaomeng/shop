//
//  MchInterfaceManager.m
//  MchInterface
//
//  Created by zhujin on 2017/7/3.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import "MchInterfaceManager.h"
#import "MchAccount.h"
#import "MchProtocol.h"
#import "MchPayInfo.h"
#import "mToast.h"

static NSString *const KETINITNOTIFICATION    = @"initNotification";
static NSString *const KETLOGINNOTIFICATION   = @"loginNotification";
static NSString *const KETLOGOUTNOTIFICATION  = @"logoutNotification";
static NSString *const KETPAYNOTIFICATION     = @"payNotification";

@interface  MchInterfaceManager()<MchAccountDelegate>{
    BOOL       initSuccess;    //sdk初始化状态
    BOOL       isEnbleLogin;   //登录权限
    BOOL       isEnblePay;     //支付权限
    BOOL       isApplePay;
    MchPayInfo   *payInfo;
}
@end

@implementation MchInterfaceManager

+ (MchInterfaceManager *)shareInstance{
    static MchInterfaceManager *interfacetool = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        interfacetool = [[MchInterfaceManager alloc] init];
    });
    return interfacetool;
}

- (void)dealloc{
    self.delegate = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:KETINITNOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:KETLOGINNOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:KETLOGOUTNOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:KETPAYNOTIFICATION object:nil];
}

- (id)init{
    if(self = [super init]){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sdkInitFinished:) name:KETINITNOTIFICATION object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginFinished:) name:KETLOGINNOTIFICATION object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didLogout:) name:KETLOGOUTNOTIFICATION object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(payFinished:) name:KETPAYNOTIFICATION object:nil];
    }
    return self;
}

- (void)doInit:(id<MchInterfaceDelegate>)target{
    
    self.delegate = target;
    NSString     *plistPath = [[NSBundle mainBundle] pathForResource:@"xigustick" ofType:@"plist"];
    NSDictionary *dic       = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
    if(dic){
        NSString *game_channel_id = [dic objectForKey:@"game_channel_id"];
        NSString *game_appid      = [dic objectForKey:@"game_appid"];
        if(game_channel_id.length > 0 || game_appid.length > 0){
            [[MchAccount shareInstance] initParams:dic delegate:self];
        }else{
            [self sdkErrorWithStatus:0 des:@"初始化:plist文件配置信息不正确"];
        }
    }else{
        [self sdkErrorWithStatus:0 des:@"初始化:缺少plist文件"];
    }
}

- (void)doLogin{
    
    if(!initSuccess){
        [[[mToast makeText:@"sdk初始化失败"] setGravity:mToastGravityBottom] show];
        return;
    }
    if(!isEnbleLogin){
        [[[mToast makeText:@"没有开启登录权限"] setGravity:mToastGravityBottom] show];
        return;
    }
    if(!SdkManager()){
        [[MchAccount shareInstance] storeLoginInfo:@"1" token:@"10241024"];
        [self loginSuccessWithUid:@"1" token:@"10241024"];
        return;
    }
    [SdkManager() doLogin];
}

- (void)doLogout{
    
    if(![[MchAccount shareInstance] isLogin]){
        [[[mToast makeText:@"当前没有登录"] setGravity:mToastGravityBottom] show];
        return;
    }
    [[MchAccount shareInstance] clearLoginInfo];
    [SdkManager() doLogout];
}

- (void)doPay:(MchPayInfo *)sdkPayInfo{
    
    if(!initSuccess){
        [[[mToast makeText:@"sdk初始化失败"] setGravity:mToastGravityBottom] show];
        return;
    }
    if(!isEnbleLogin || !isEnblePay){
        [[[mToast makeText:@"没有开启支付权限"] setGravity:mToastGravityBottom] show];
        return;
    }
    if(![[MchAccount shareInstance] isLogin]){
        [[[mToast makeText:@"当前没有登录"] setGravity:mToastGravityBottom] show];
        return;
    }
    isApplePay = NO;
    payInfo = sdkPayInfo;
    [[MchAccount shareInstance] createOrder:sdkPayInfo];
}

- (void)doApplePay:(MchPayInfo *)sdkPayInfo{

    if(!initSuccess){
        [[[mToast makeText:@"sdk初始化失败"] setGravity:mToastGravityBottom] show];
        return;
    }
    if(!isEnbleLogin || !isEnblePay){
        [[[mToast makeText:@"没有开启支付权限"] setGravity:mToastGravityBottom] show];
        return;
    }
    if(![[MchAccount shareInstance] isLogin]){
        [[[mToast makeText:@"当前没有登录"] setGravity:mToastGravityBottom] show];
        return;
    }
    isApplePay = YES;
    payInfo = sdkPayInfo;
    [[MchAccount shareInstance] createOrder:sdkPayInfo];
}

- (void)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options{
    [SdkManager() application:application openURL:url options:options];
}

- (void)application:(UIApplication *)application openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation{
    [SdkManager() application:application openURL:url sourceApplication:sourceApplication annotation:annotation];
}

#pragma mark - MchAccountDelegate
- (void)initSdkResultlogin:(BOOL)enableLogin pay:(BOOL)enablePay{
    isEnbleLogin = enableLogin;
    isEnblePay   = enablePay;
    if(!SdkManager()){
        initSuccess = YES;
        if(self.delegate && [self.delegate respondsToSelector:@selector(mchInitResult:)]){
            [self.delegate mchInitResult:initSuccess];
        }
        return;
    }
    [SdkManager() initSdkWithAppId:[MchAccount shareInstance].sdkInfo.appid andAppKey:[MchAccount shareInstance].sdkInfo.appkey];
}

- (void)loginSuccessWithUid:(NSString *)user_id token:(NSString *)user_token{
    if(self.delegate && [self.delegate respondsToSelector:@selector(mchLoginSuccessWithUid:token:)]){
        [self.delegate mchLoginSuccessWithUid:user_id token:user_token];
    }
}

- (void)createOrderSuccess{

    if(self.delegate && [self.delegate respondsToSelector:@selector(mchCreateOrderResult:)]){
        [self.delegate mchCreateOrderResult:YES];
    }
    if(isApplePay){
        [SdkManager() doApplePay:payInfo];
    }else{
        [SdkManager() doPay:payInfo];
    }
}

//state 0初始化 1登录 2创建订单
- (void)sdkErrorWithStatus:(NSInteger)state des:(NSString *)errorInfo{
    if(state == 0){
        initSuccess = NO;
        if(self.delegate && [self.delegate respondsToSelector:@selector(mchInitResult:)]){
            [self.delegate mchInitResult:initSuccess];
        }
    }else if (state == 1){
        if(self.delegate && [self.delegate respondsToSelector:@selector(mchLoginFail)]){
            [self.delegate mchLoginFail];
        }
    }else if (state == 2){
        if(self.delegate && [self.delegate respondsToSelector:@selector(mchCreateOrderResult:)]){
            [self.delegate mchCreateOrderResult:NO];
        }
    }
    [[[mToast makeText:errorInfo] setGravity:mToastGravityBottom] show];
}


#pragma mark - NSNotification
- (void)sdkInitFinished:(NSNotification *)notification{
    NSDictionary *notifyUserInfo = [notification object];
    if(notifyUserInfo.allKeys.count <= 0){
        return;
    }
    NSInteger state = [[notifyUserInfo objectForKey:@"state"] integerValue];
    if(state == 1){
        initSuccess = YES;
    }else{
        initSuccess = NO;
    }
    if(self.delegate && [self.delegate respondsToSelector:@selector(mchInitResult:)]){
        [self.delegate mchInitResult:initSuccess];
    }
}

- (void)loginFinished:(NSNotification *)notification{
    NSDictionary *notifyUserInfo = [notification object];
    if(notifyUserInfo.allKeys.count <= 0){
        return;
    }
    NSInteger state = [[notifyUserInfo objectForKey:@"state"] integerValue];
    if(state == 1){
        NSString *userId = [notifyUserInfo objectForKey:@"userId"];
        NSString *token = [notifyUserInfo objectForKey:@"token"];
        [[MchAccount shareInstance] storeLoginInfo:userId token:token];
        [[MchAccount shareInstance] doLogin];
    }else if(state == 0){
        if(self.delegate && [self.delegate respondsToSelector:@selector(mchLoginFail)]){
            [self.delegate mchLoginFail];
        }
    }
}

- (void)didLogout:(NSNotification *)notification{
    NSDictionary *notifyUserInfo = [notification object];
    if(notifyUserInfo.allKeys.count <= 0){
        return;
    }
    NSInteger state = [[notifyUserInfo objectForKey:@"state"] integerValue];
    if(state == 1){
        if(self.delegate && [self.delegate respondsToSelector:@selector(mchDidLogout:)]){
            [self.delegate mchDidLogout:YES];
        }
    }else{
        if(self.delegate && [self.delegate respondsToSelector:@selector(mchDidLogout:)]){
            [self.delegate mchDidLogout:NO];
        }
    }
}

- (void)payFinished:(NSNotification *)notification{
    NSDictionary *notifyUserInfo = [notification object];
    if(notifyUserInfo.allKeys.count <= 0){
        return;
    }
    NSInteger state = [[notifyUserInfo objectForKey:@"state"] integerValue];
    if(state == 1){
        if(self.delegate && [self.delegate respondsToSelector:@selector(mchPayResult:)]){
            [self.delegate mchPayResult:YES];
        }
    }else if(state == 0){
        if(self.delegate && [self.delegate respondsToSelector:@selector(mchPayResult:)]){
            [self.delegate mchPayResult:NO];
        }
    }
}

@end





