//
//  MchAccount.m
//  MchInterface
//
//  Created by zhujin on 2017/8/1.
//  Copyright © 2017年 zhujin. All rights reserved.
//
//
#import "MchAccount.h"
#import "NSMutableDictionary+MSafe.h"
#import "MchHttpManager.h"
#import "MchConstant.h"

#define DistributionModel    0   //切换到正式环境置为1，测试环境为0 或注释

#if DistributionModel
NSString * const kWebServiceBaseURL =  @"http://faxing.vlcms.com/sdk.php";
#else
NSString * const kWebServiceBaseURL =  @"http://ceh5.vlcms.com/sdk.php";
#endif

@implementation MchAccount

+ (MchAccount *)shareInstance{
    static MchAccount *accountTool = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        accountTool = [[MchAccount alloc] init];
    });
    return accountTool;
}

- (void)dealloc{
    self.delegate = nil;
}

- (BOOL)isLogin{
    if(self.uid.length > 0 && self.token.length > 0){
        return YES;
    }
    return NO;
}

- (void)clearLoginInfo{
    self.uid   = @"";
    self.token = @"";
}

- (void)storeLoginInfo:(NSString *)userId token:(NSString *)token{
    self.uid    = userId;
    self.token  = token;
}

- (void)initParams:(NSDictionary *)dic delegate:(id<MchAccountDelegate>)target{
    self.delegate = target;
    _sdkInfo = [[MchSdkInfo alloc] initParamsWithDic:dic];
    [self checkAuthorizationState];
}

- (void)checkAuthorizationState{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    if(_sdkInfo.game_channel_id.length > 0){
        [params msafeSetObject:_sdkInfo.game_channel_id forKey:@"game_channel_id"];
    }
    if(_sdkInfo.game_appid.length > 0){
        [params msafeSetObject:_sdkInfo.game_appid forKey:@"game_appid"];
    }
    [params msafeSetObject:@"2" forKey:@"sdk_os"];
    params = [self sortDicToString:params];
    
    [[MchHttpManager shareInstance] sendPOSTWithUrl:[NSString stringWithFormat:@"%@?s=/ChannelUser/channel_pack_status",kWebServiceBaseURL] parameters:params success:^(id resultDic){
        NSDictionary *dict = (NSDictionary *)resultDic;
        NSLog(@"channel_pack_status---------%@",dict);
        NSInteger code = [[dict objectForKey:@"status"] integerValue];
        if(code == 1){
            BOOL isEnbleLogin = [[dict objectForKey:@"login"] boolValue];
            BOOL isEnblePay   = [[dict objectForKey:@"pay"] boolValue];
            if(self.delegate && [self.delegate respondsToSelector:@selector(initSdkResultlogin:pay:)]){
                [self.delegate  initSdkResultlogin:isEnbleLogin pay:isEnblePay];
            }
        }else{
            if(self.delegate && [self.delegate respondsToSelector:@selector(sdkErrorWithStatus:des:)]){
                [self.delegate sdkErrorWithStatus:0 des:[dict objectForKey:@"return_msg"]];
            }
        }
    }fail:^(NSError *error){
        if(self.delegate && [self.delegate respondsToSelector:@selector(sdkErrorWithStatus:des:)]){
            [self.delegate sdkErrorWithStatus:0 des:@"初始化:获取渠道状态失败"];
        }
    }];
}

- (void)doLogin{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params msafeSetObject:_sdkInfo.game_channel_id forKey:@"game_channel_id"];
    [params msafeSetObject:@"2" forKey:@"sdk_os"];
    [params msafeSetObject:self.uid forKey:@"channel_uid"];
    [params msafeSetObject:self.token forKey:@"token"];
    params = [self sortDicToString:params];
    
    [[MchHttpManager shareInstance] sendPOSTWithUrl:[NSString stringWithFormat:@"%@?s=/ChannelUser/user_login",kWebServiceBaseURL] parameters:params success:^(id resultDic){
        NSDictionary *dict = (NSDictionary *)resultDic;
        NSInteger code = [[dict objectForKey:@"status"] integerValue];
        if(code == 1){
            NSString *user_id    = [dict objectForKey:@"user_id"];
            NSString *user_token = [dict objectForKey:@"token"];
            if(self.delegate && [self.delegate respondsToSelector:@selector(loginSuccessWithUid:token:)]){
                [self.delegate loginSuccessWithUid:user_id token:user_token];
            }
        }else{
            [self clearLoginInfo];
            if(self.delegate && [self.delegate respondsToSelector:@selector(sdkErrorWithStatus:des:)]){
                [self.delegate sdkErrorWithStatus:1 des:[dict objectForKey:@"return_msg"]];
            }
        }
    }fail:^(NSError *error){
        [self clearLoginInfo];
        if(self.delegate && [self.delegate respondsToSelector:@selector(sdkErrorWithStatus:des:)]){
            [self.delegate sdkErrorWithStatus:1 des:@"登录失败"];
        }
    }];
}

- (void)createOrder:(MchPayInfo *)orderInfo{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    if(_sdkInfo.game_channel_id.length > 0){
        [params msafeSetObject:_sdkInfo.game_channel_id forKey:@"game_channel_id"];
    }
    if(_sdkInfo.game_appid.length > 0){
        [params msafeSetObject:_sdkInfo.game_appid forKey:@"game_appid"];
    }
    [params msafeSetObject:@"2" forKey:@"sdk_os"];
    [params msafeSetObject:self.uid forKey:@"channel_uid"];
    [params msafeSetObject:self.token forKey:@"token"];
    [params msafeSetObject:orderInfo.goodsName forKey:@"props_name"];
    [params msafeSetObject:orderInfo.goodsPrice forKey:@"pay_amount"];
    [params msafeSetObject:orderInfo.extendInfo forKey:@"extend"];
    params = [self sortDicToString:params];
    
    [[MchHttpManager shareInstance] sendPOSTWithUrl:[NSString stringWithFormat:@"%@?s=/ChannelPay/pay_create",kWebServiceBaseURL] parameters:params success:^(id resultDic){
        NSDictionary *dict = (NSDictionary *)resultDic;
        NSInteger code = [[dict objectForKey:@"status"] integerValue];
        if(code == 1){
            if(self.delegate && [self.delegate respondsToSelector:@selector(createOrderSuccess)]){
                [self.delegate createOrderSuccess];
            }
        }else{
            if(self.delegate && [self.delegate respondsToSelector:@selector(sdkErrorWithStatus:des:)]){
                [self.delegate sdkErrorWithStatus:2 des:[dict objectForKey:@"return_msg"]];
            }
        }
    }fail:^(NSError *error){
        if(self.delegate && [self.delegate respondsToSelector:@selector(sdkErrorWithStatus:des:)]){
            [self.delegate sdkErrorWithStatus:2 des:@"创建订单失败"];
        }
    }];
}

- (NSMutableDictionary *)sortDicToString:(NSMutableDictionary *)param{
    //排序
    NSMutableArray *stringArray = [NSMutableArray arrayWithArray:param.allKeys];
    [stringArray sortUsingComparator: ^NSComparisonResult (NSString *str1, NSString *str2){
        return [str1 compare:str2];
    }];
    //验签
    NSString *md5StrPre = @"";
    for(int i = 0; i < [stringArray count]; i++){
        NSString *key = [stringArray objectAtIndex:i];
        md5StrPre = [md5StrPre stringByAppendingString:[param objectForKey:key]];
    }
    md5StrPre = [md5StrPre stringByAppendingString:[[MchConstant sharedInstance] getMCHKey]];
    NSString *md5Str = [MchConstant param_md5:md5StrPre];
    [param msafeSetObject:md5Str forKey:@"md5_sign"];
    NSLog(@"[MchHttpManager] sort param = %@", param);
    return param;
}

@end




