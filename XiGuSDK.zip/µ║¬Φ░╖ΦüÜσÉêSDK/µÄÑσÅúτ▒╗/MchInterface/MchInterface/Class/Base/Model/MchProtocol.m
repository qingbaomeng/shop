//
//  MchProtocol.m
//  MchInterface
//
//  Created by zhujin on 2017/8/10.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import "MchProtocol.h"

id<MchProtocol> SdkManager(){
    Class<MchProtocol> classA  = NSClassFromString(@"SdkManager");
    if(classA){
        id<MchProtocol> object = [classA shareInstance];
        return object;
    }
    return nil;
}



