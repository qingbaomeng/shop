//
//  MchProtocol.h
//  MchInterface
//
//  Created by zhujin on 2017/8/10.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol MchProtocol <NSObject>

+ (id)shareInstance;
/**
 * 初始化sdk
 */
- (void)initSdkWithAppId:(NSString *)appId andAppKey:(NSString *)appKey;
/**
 *  登录
 */
- (void)doLogin;
/**
 *  注销
 */
- (void)doLogout;
/**
 *  sdk支付
 */
- (void)doPay:(id)sdkPayInfo;
- (void)doApplePay:(id)sdkPayInfo;
/**
 *  溪谷sdk调用的方法
 */
- (void)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options;
- (void)application:(UIApplication *)application openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation;
@end


id<MchProtocol> SdkManager();







