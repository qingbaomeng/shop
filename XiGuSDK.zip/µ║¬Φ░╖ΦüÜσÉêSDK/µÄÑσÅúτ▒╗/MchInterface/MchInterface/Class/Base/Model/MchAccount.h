//
//  MchAccount.h
//  MchInterface
//
//  Created by zhujin on 2017/8/1.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MchSdkInfo.h"
#import "MchPayInfo.h"

@protocol MchAccountDelegate <NSObject>
- (void)initSdkResultlogin:(BOOL)enableLogin pay:(BOOL)enablePay;
- (void)loginSuccessWithUid:(NSString *)user_id token:(NSString *)user_token;
- (void)createOrderSuccess;
//state 0初始化 1登录 2创建订单
- (void)sdkErrorWithStatus:(NSInteger)state des:(NSString *)errorInfo;
@end

@interface MchAccount : NSObject
@property (nonatomic,weak) id <MchAccountDelegate>delegate;
@property (nonatomic,strong) MchSdkInfo   *sdkInfo;
@property (nonatomic,strong) NSString     *uid;
@property (nonatomic,strong) NSString     *token;

+ (MchAccount *)shareInstance;
/**
 *  是否登录
 */
- (BOOL)isLogin;
/**
 *  清除用户信息
 */
- (void)clearLoginInfo;
/**
 *  保存用户信息
 */
- (void)storeLoginInfo:(NSString *)userId token:(NSString *)token;
/**
 *  初始化参数
 */
- (void)initParams:(NSDictionary *)dic delegate:(id<MchAccountDelegate>)target;
/**
 *  登录
 */
- (void)doLogin;
/**
 *  创建支付订单
 */
- (void)createOrder:(MchPayInfo *)orderInfo;

@end



