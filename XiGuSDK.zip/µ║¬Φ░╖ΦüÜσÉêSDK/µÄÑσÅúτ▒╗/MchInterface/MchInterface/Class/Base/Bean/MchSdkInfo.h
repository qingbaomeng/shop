//
//  MchSdkInfo.h
//  MchInterface
//
//  Created by zhujin on 2017/7/31.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  读取xigustick.plist文件信息
 */
@interface MchSdkInfo : NSObject
@property (nonatomic,strong) NSString   *game_channel_id;
@property (nonatomic,strong) NSString   *game_appid;
@property (nonatomic,strong) NSString   *appid;
@property (nonatomic,strong) NSString   *appkey;
- (id)initParamsWithDic:(NSDictionary *)dic;
@end
