//
//  MchSdkInfo.m
//  MchInterface
//
//  Created by zhujin on 2017/7/31.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import "MchSdkInfo.h"

@implementation MchSdkInfo

- (id)initParamsWithDic:(NSDictionary *)dic{
    if(self = [super init]){
        if([dic objectForKey:@"game_channel_id"] && [[dic objectForKey:@"game_channel_id"] isKindOfClass:[NSString class]]){
            self.game_channel_id = [dic objectForKey:@"game_channel_id"];
        }else{
            self.game_channel_id = @"";
        }
        if([dic objectForKey:@"game_appid"] && [[dic objectForKey:@"game_appid"] isKindOfClass:[NSString class]]){
            self.game_appid = [dic objectForKey:@"game_appid"];
        }else{
            self.game_appid = @"";
        }
        if([dic objectForKey:@"appid"] && [[dic objectForKey:@"appid"] isKindOfClass:[NSString class]]){
            self.appid = [dic objectForKey:@"appid"];
        }else{
            self.appid = @"";
        }
        if([dic objectForKey:@"appkey"] && [[dic objectForKey:@"appkey"] isKindOfClass:[NSString class]]){
            self.appkey = [dic objectForKey:@"appkey"];
        }else{
            self.appkey = @"";
        }
    }
    return self;
}

@end
