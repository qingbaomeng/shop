//
//  MchConstant.m
//  MchInterface
//
//  Created by pippo on 2017/7/4.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import "MchConstant.h"
#import <CommonCrypto/CommonDigest.h>

static const char encodingTable[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static NSString   *const gamekey  = @"CgsPEgsLEg8LCg==";

@implementation MchConstant
@synthesize urlKey;

+ (MchConstant *)sharedInstance{
    static MchConstant *mchConstant = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        mchConstant = [[MchConstant alloc] init];
    });
    return mchConstant;
}

- (id)init{
    if(self = [super init]){
        urlKey = @"";
    }
    return self;
}

- (NSString *)getMCHKey{
    if([@"" isEqualToString:urlKey]){
        NSString *keyEncode = gamekey;
        if([@"mengchuang" isEqualToString:keyEncode]){
            urlKey = @"mengchuang";
            return urlKey;
        }
        urlKey = [self decodeKey:keyEncode];
    }
    return urlKey;
}

- (NSString *)decodeKey:(NSString *)encodeStr{
    NSData *nsdataFromBase64String = [[NSData alloc] initWithBase64EncodedString:encodeStr options:0];
    Byte *testByte = (Byte *)[nsdataFromBase64String bytes];
    
    NSString *keyStr = @"gnauhcgnem";
    NSData *keyData = [keyStr dataUsingEncoding: NSUTF8StringEncoding];
    Byte *keyByte = (Byte *)[keyData bytes];
    
    NSUInteger j = [keyData length];
    NSUInteger decodedL = [nsdataFromBase64String length];
    Byte byte[decodedL];
    int m = 0;
    for(int i = 0; i < decodedL; i++){
        byte[i] = testByte[i] ^ keyByte[m >= j ? m = 0 : m++];
    }
    
    NSData *adata = [[NSData alloc] initWithBytes:byte length:decodedL];
    NSString *resStr = [[NSString alloc] initWithData:adata encoding:NSUTF8StringEncoding];
    NSLog(@"resStr=%@", resStr);
    if(!resStr){
        return @"mengchuang";
    }
    return resStr;
}

+ (NSString *)textFromBase64String:(NSString *)base64{
    if(base64 && ![base64 isEqualToString:@""]){
        NSData *data = [[self class] dataWithBase64EncodedString:base64];
        return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }else{
        return @"";
    }
}

+ (NSData *)dataWithBase64EncodedString:(NSString *)string{
    if(string == nil)
        [NSException raise:NSInvalidArgumentException format:nil];
    if([string length] == 0)
        return [NSData data];
    
    static char *decodingTable = NULL;
    if(decodingTable == NULL){
        decodingTable = malloc(256);
        if(decodingTable == NULL)
            return nil;
        memset(decodingTable, CHAR_MAX, 256);
        NSUInteger i;
        for (i = 0; i < 64; i++)
            decodingTable[(short)encodingTable[i]] = i;
    }
    
    const char *characters = [string cStringUsingEncoding:NSASCIIStringEncoding];
    if(characters == NULL)     //  Not an ASCII string!
        return nil;
    char *bytes = malloc((([string length] + 3) / 4) * 3);
    if(bytes == NULL)
        return nil;
    NSUInteger length = 0;
    
    NSUInteger i = 0;
    while (YES)
    {
        char buffer[4];
        short bufferLength;
        for(bufferLength = 0; bufferLength < 4; i++){
            if(characters[i] == '\0')
                break;
            if(isspace(characters[i]) || characters[i] == '=')
                continue;
            buffer[bufferLength] = decodingTable[(short)characters[i]];
            if(buffer[bufferLength++] == CHAR_MAX)      //  Illegal character!
            {
                free(bytes);
                return nil;
            }
        }
        if(bufferLength == 0)
            break;
        if(bufferLength == 1)      //  At least two characters are needed to produce one byte!
        {
            free(bytes);
            return nil;
        }
        
        //  Decode the characters in the buffer to bytes.
        bytes[length++] = (buffer[0] << 2) | (buffer[1] >> 4);
        if(bufferLength > 2)
            bytes[length++] = (buffer[1] << 4) | (buffer[2] >> 2);
        if(bufferLength > 3)
            bytes[length++] = (buffer[2] << 6) | buffer[3];
    }
    bytes = realloc(bytes, length);
    return [NSData dataWithBytesNoCopy:bytes length:length];
}

+ (NSString *)param_md5:(NSString *)str{
    const char *cStr = [str UTF8String];
    unsigned char result[32];
    CC_MD5( cStr, (int)strlen(cStr), result);
    NSMutableString *hash = [NSMutableString string];
    for(int i = 0; i < 16; i++){
        [hash appendFormat:@"%02X", result[i]];
    }
    return [hash lowercaseString];
}


@end




