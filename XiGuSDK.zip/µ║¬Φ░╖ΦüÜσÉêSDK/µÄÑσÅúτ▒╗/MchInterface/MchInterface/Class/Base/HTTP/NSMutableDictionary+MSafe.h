//
//  NSMutableDictionary+Safe.h
//  ECalendar-Pro
//
//  Created by suishen.mobi on 14-1-2.
//  Copyright (c) 2014年 etouch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableDictionary (MSafe)
/**
 *  字典的安全使用
 */
- (BOOL)msafeSetObject:(id)anObject forKey:(id<NSCopying>)key;

@end


