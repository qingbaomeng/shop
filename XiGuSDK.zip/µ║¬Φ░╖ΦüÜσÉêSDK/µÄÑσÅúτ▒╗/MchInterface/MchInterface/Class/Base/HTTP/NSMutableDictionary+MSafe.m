//
//  NSMutableDictionary+Safe.m
//  ECalendar-Pro
//
//  Created by suishen.mobi on 14-1-2.
//  Copyright (c) 2014年 etouch. All rights reserved.
//

#import "NSMutableDictionary+MSafe.h"

@implementation NSMutableDictionary (MSafe)

- (BOOL)msafeSetObject:(id)anObject forKey:(id<NSCopying>)key{
    if(anObject && key){
        [self setObject:anObject forKey:key];
        return YES;
    }else{
        return NO;
    }
}

@end



