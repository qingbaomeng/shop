//
//  MchHttpManager.h
//  MchInterface
//
//  Created by zhujin on 2017/7/4.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^SuccessBlock)(id resultDic);
typedef void(^FailBlock)(NSError *error);

/**
 *  网络请求
 */
@interface MchHttpManager : NSObject
+ (MchHttpManager *)shareInstance;
- (void)sendPOSTWithUrl:(NSString *)url parameters:(NSDictionary *)dict success:(SuccessBlock)successBlock fail:(FailBlock)failBlock;
@end
