//
//  MchHttpManager.m
//  MchInterface
//
//  Created by zhujin on 2017/7/4.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import "MchHttpManager.h"
#import "MchConstant.h"

@interface MchHttpManager(){
    NSOperationQueue *queue;
}
@end

@implementation MchHttpManager

+ (MchHttpManager *)shareInstance{
    static MchHttpManager *httpManager = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        httpManager = [[MchHttpManager alloc] init];
    });
    return httpManager;
}

- (id)init{
    self = [super init];
    if(self){
        queue = [NSOperationQueue mainQueue];
    }
    return self;
}

- (void)sendPOSTWithUrl:(NSString *)url parameters:(NSDictionary *)dict success:(SuccessBlock)successBlock fail:(FailBlock)failBlock{
    
    NSData *bodyData  = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:nil];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:bodyData];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError){
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        NSInteger code = httpResponse.statusCode;
        if(code == 200){
            NSString *resultStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"[MchHttpManager] resultStr : %@",resultStr);
            NSString *res = [MchConstant textFromBase64String:resultStr];
            NSLog(@"[MchHttpManager] res : %@", res);
            if(res && ![@"" isEqualToString:res]){
                NSData *jsonData = [res dataUsingEncoding:NSUTF8StringEncoding];
                if(jsonData){
                    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:jsonData options:kNilOptions error:nil];
                    successBlock(responseDictionary);
                }else{
                    NSError *error = [[NSError alloc] initWithDomain:@"结果异常" code:-1 userInfo:nil];
                    failBlock(error);
                }
            }else{
                NSLog(@"[MchHttpManager] 数据转base64错误");
                NSError *error = [[NSError alloc] initWithDomain:@"结果异常" code:-1 userInfo:nil];
                failBlock(error);
            }
        }else{
            NSLog(@"[MchHttpManager] error : %@",connectionError);
            failBlock(connectionError);
        }
    }];
}


@end




