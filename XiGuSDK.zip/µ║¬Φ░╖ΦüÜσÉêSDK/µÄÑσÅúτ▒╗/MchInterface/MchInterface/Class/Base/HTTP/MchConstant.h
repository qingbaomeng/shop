//
//  MchConstant.h
//  MchInterface
//
//  Created by pippo on 2017/7/4.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MchConstant : NSObject
@property (nonatomic,strong) NSString *urlKey;

+ (MchConstant *)sharedInstance;
/**
 *  获取验签key
 */
- (NSString *)getMCHKey;
/**
 *  base64解密
 */
+ (NSString *)textFromBase64String:(NSString *)base64;
/**
 *  md5加密
 */
+ (NSString *)param_md5:(NSString *)str;

@end
