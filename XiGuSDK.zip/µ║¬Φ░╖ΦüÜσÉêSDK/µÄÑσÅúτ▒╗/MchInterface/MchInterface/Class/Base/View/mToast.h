//
//  iToast.h
//  iToast
//
//  Created by Diallo Mamadou Bobo on 2/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef enum mToastGravity{
	mToastGravityTop = 1000001,
	mToastGravityBottom,
	mToastGravityCenter
}mToastGravity;

typedef enum mToastDuration{
	mToastDurationLong = 10000,
	mToastDurationShort = 1000,
	mToastDurationNormal = 3000
}mToastDuration;

typedef enum mToastType{
	mToastTypeInfo = -100000,
	mToastTypeNotice,
	mToastTypeWarning,
	mToastTypeError,
	mToastTypeNone // For internal use only (to force no image)
}mToastType;


@class mToastSettings;

@interface mToast : NSObject{
	mToastSettings *_settings;
	NSInteger offsetLeft;
	NSInteger offsetTop;
	
	NSTimer  *timer;
	UIView   *view;
	NSString *text;
}
- (void)show;
- (void)show:(mToastType)type;
+ (mToast *)makeText:(NSString *)text;
- (mToast *)setDuration:(NSInteger)duration;
- (mToast *)setGravity:(mToastGravity)gravity
			 offsetLeft:(NSInteger)left
			 offsetTop:(NSInteger)top;
- (mToast *)setGravity:(mToastGravity)gravity;
- (mToast *)setPostion:(CGPoint)position;
- (mToastSettings *)theSettings;
@end



@interface mToastSettings : NSObject<NSCopying>{
	NSInteger    duration;
	mToastGravity gravity;
	CGPoint    postition;
	NSDictionary *images;
}
@property(assign) NSInteger duration;
@property(assign) mToastGravity gravity;
@property(assign) CGPoint postition;
@property(readonly) NSDictionary *images;
- (void)setImage:(UIImage *)img forType:(mToastType)type;
+ (mToastSettings *)getSharedSettings;
@end



