//
//  iToast.m
//  iToast
//
//  Created by Diallo Mamadou Bobo on 2/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "mToast.h"
#import <QuartzCore/QuartzCore.h>

static mToastSettings *sharedSettings = nil;

@interface mToast(private)
- (mToast *)settings;
@end

@implementation mToast

- (id)initWithText:(NSString *)tex{
	if(self = [super init]){
		text = [tex copy];
	}
	return self;
}

- (void)show{
	[self show:mToastTypeNone];
}

- (void)show:(mToastType)type{
	mToastSettings *theSettings = _settings;
	if(!theSettings){
		theSettings = [mToastSettings getSharedSettings];
	}
	UIImage *image = [theSettings.images valueForKey:[NSString stringWithFormat:@"%i", type]];
    UIFont  *font  = [UIFont systemFontOfSize:14];
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:text
                                        attributes:@{NSFontAttributeName: font}];
    CGRect frame = [attributedText boundingRectWithSize:CGSizeMake(280, 60)
                                               options:NSStringDrawingUsesLineFragmentOrigin context:nil];
    CGSize textSize = frame.size;
    UILabel *label  = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, textSize.width + 5, textSize.height + 5)];
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [UIColor whiteColor];
	label.font = font;
	label.text = text;
	label.numberOfLines = 0;
	label.shadowColor   = [UIColor colorWithWhite:0 alpha:0.3];
	label.shadowOffset  = CGSizeMake(0, 1);
    label.textAlignment = NSTextAlignmentCenter;
	
	UIButton *v = [UIButton buttonWithType:UIButtonTypeCustom];
	if(image){
		v.frame = CGRectMake(0, 0, image.size.width + textSize.width + 32, MAX(textSize.height, image.size.height) + 16);
        int h=v.frame.size.height/2;
        int w=image.size.width + 32 + (v.frame.size.width - image.size.width - 16) / 2;
		label.center = CGPointMake(w, h);
	}else{
		v.frame = CGRectMake(0, 0, textSize.width + 32, textSize.height + 16);
        CGRect frame = label.frame;
        int x = (v.frame.size.width-frame.size.width) / 2;
        int y = (v.frame.size.height-frame.size.height)/2;
        frame.origin.x=x;frame.origin.y=y;
		label.frame=frame;
	}
	[v addSubview:label];
	[label release];
	
	if(image){
		UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
		imageView.frame = CGRectMake(5, (v.frame.size.height - image.size.height)/2, image.size.width, image.size.height);
		[v addSubview:imageView];
		[imageView release];
	}
	v.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.8];
	v.layer.cornerRadius = 4;
	
	UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
	
	CGPoint point = CGPointZero;
	
	// Set correct orientation/location regarding device orientation
	UIInterfaceOrientation orientation = (UIInterfaceOrientation)[[UIApplication sharedApplication] statusBarOrientation];
	switch (orientation){
		case UIDeviceOrientationPortrait:
		{
			if(theSettings.gravity == mToastGravityTop){
				point = CGPointMake(window.frame.size.width / 2, 45);
			}else if (theSettings.gravity == mToastGravityBottom){
				point = CGPointMake(window.frame.size.width / 2, window.frame.size.height - 45);
			}else if(theSettings.gravity == mToastGravityCenter){
				point = CGPointMake(window.frame.size.width/2, window.frame.size.height/2);
			}else{
				point = theSettings.postition;
			}
			point = CGPointMake(point.x + offsetLeft, point.y + offsetTop);
			break;
		}
		case UIDeviceOrientationPortraitUpsideDown:
		{
			v.transform = CGAffineTransformMakeRotation(M_PI);
			
			float width = window.frame.size.width;
			float height = window.frame.size.height;
			
			if(theSettings.gravity == mToastGravityTop){
				point = CGPointMake(width / 2, height - 45);
			}else if (theSettings.gravity == mToastGravityBottom){
				point = CGPointMake(width / 2, 45);
			}else if (theSettings.gravity == mToastGravityCenter){
				point = CGPointMake(width/2, height/2);
			}else{
				// TODO : handle this case
				point = theSettings.postition;
			}
			point = CGPointMake(point.x - offsetLeft, point.y - offsetTop);
			break;
		}
		case UIDeviceOrientationLandscapeLeft:
		{
			v.transform = CGAffineTransformMakeRotation(M_PI/2); //rotation in radians
			
			if(theSettings.gravity == mToastGravityTop){
				point = CGPointMake(window.frame.size.width - 45, window.frame.size.height / 2);
			}else if (theSettings.gravity == mToastGravityBottom){
				point = CGPointMake(45,window.frame.size.height / 2);
			}else if (theSettings.gravity == mToastGravityCenter){
				point = CGPointMake(window.frame.size.width/2, window.frame.size.height/2);
			}else{
				// TODO : handle this case
				point = theSettings.postition;
			}
			point = CGPointMake(point.x - offsetTop, point.y - offsetLeft);
			break;
		}
		case UIDeviceOrientationLandscapeRight:
		{
			v.transform = CGAffineTransformMakeRotation(-M_PI/2);
			
			if(theSettings.gravity == mToastGravityTop){
				point = CGPointMake(45, window.frame.size.height / 2);
			}else if (theSettings.gravity == mToastGravityBottom){
				point = CGPointMake(window.frame.size.width - 45, window.frame.size.height/2);
			}else if (theSettings.gravity == mToastGravityCenter){
				point = CGPointMake(window.frame.size.width/2, window.frame.size.height/2);
			}else{
				// TODO : handle this case
				point = theSettings.postition;
			}
			point = CGPointMake(point.x + offsetTop, point.y + offsetLeft);
			break;
		}
		default:
			break;
	}
	v.center = point;
	
	NSTimer *timer1 = [NSTimer timerWithTimeInterval:((float)theSettings.duration)/1000 target:self selector:@selector(hideToast:) userInfo:nil repeats:NO];
	[[NSRunLoop mainRunLoop] addTimer:timer1 forMode:NSDefaultRunLoopMode];
	[window addSubview:v];
	view = [v retain];
	[v addTarget:self action:@selector(hideToast:) forControlEvents:UIControlEventTouchDown];
}

- (void)hideToast:(NSTimer *)theTimer{
    [view removeFromSuperview];
	[UIView beginAnimations:nil context:NULL];
	view.alpha = 0;
	[UIView commitAnimations];
	
	NSTimer *timer2 = [NSTimer timerWithTimeInterval:500 target:self selector:@selector(hideToast:) userInfo:nil repeats:NO];
	[[NSRunLoop mainRunLoop] addTimer:timer2 forMode:NSDefaultRunLoopMode];
}

+ (mToast *)makeText:(NSString *)_text{
    if(_text == nil){
        _text = @"";
    }
	mToast *toast = [[[mToast alloc] initWithText:_text] autorelease];
	return toast;
}

- (mToast *)setDuration:(NSInteger)duration{
	[self theSettings].duration = duration;
	return self;
}

- (mToast *)setGravity:(mToastGravity)gravity
			 offsetLeft:(NSInteger)left
			  offsetTop:(NSInteger)top{
	[self theSettings].gravity = gravity;
	offsetLeft = left;
	offsetTop  = top;
	return self;
}

- (mToast *)setGravity:(mToastGravity)gravity{
	[self theSettings].gravity = gravity;
	return self;
}

- (mToast *)setPostion:(CGPoint)_position{
	[self theSettings].postition = CGPointMake(_position.x, _position.y);
	return self;
}

- (mToastSettings *)theSettings{
	if(!_settings){
		_settings = [[mToastSettings getSharedSettings] copy];
	}
	return _settings;
}

@end


@implementation mToastSettings
@synthesize duration;
@synthesize gravity;
@synthesize postition;
@synthesize images;

- (void)setImage:(UIImage *)img forType:(mToastType)type{
	if(type == mToastTypeNone){
		// This should not be used, internal use only (to force no image)
		return;
	}
	if(!images){
		images = [[NSMutableDictionary alloc] initWithCapacity:4];
	}
	if(img){
		NSString *key = [NSString stringWithFormat:@"%i", type];
		[images setValue:img forKey:key];
	}
}

+ (mToastSettings *)getSharedSettings{
	if(!sharedSettings){
		sharedSettings = [mToastSettings new];
		sharedSettings.gravity  = mToastGravityCenter;
		sharedSettings.duration = mToastDurationShort;
	}
	return sharedSettings;
}

- (id)copyWithZone:(NSZone *)zone{
	mToastSettings *copy = [mToastSettings new];
	copy.gravity   = self.gravity;
	copy.duration  = self.duration;
	copy.postition = self.postition;
	NSArray *keys  = [self.images allKeys];
	for(NSString *key in keys){
		[copy setImage:[images valueForKey:key] forType:[key intValue]];
	}
	return copy;
}


@end




