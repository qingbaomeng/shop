//
//  TestXiguViewController.m
//  MchInterfacDemo
//
//  Created by zhujin on 2017/7/3.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import "TestXiguViewController.h"
#import <MchInterface/MchInterface.h>

@interface TestXiguViewController ()<UITableViewDelegate,UITableViewDataSource,MchInterfaceDelegate>{
    UITableView *myTableView;
    NSArray     *dataArray;
    NSInteger   loginState;
}
@end

@implementation TestXiguViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"聚合sdk";
 
    dataArray = @[@"登录",@"支付",@"应用内支付",@"注销"];
    loginState = 0;
    
    myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    myTableView.backgroundColor = [UIColor grayColor];
    myTableView.delegate = self;
    myTableView.dataSource = self;
    myTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    [self.view addSubview:myTableView];
    
    UIView *footview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width , 100)];
    myTableView.tableFooterView = footview;
    [MchInterfaceManager shareInstance].delegate = self;
}

- (void)logoutRefresh:(NSInteger)state{
    loginState = state;
    [myTableView reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *identifier = @"testdemo";
    UITableViewCell *cell = [myTableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.backgroundColor = [UIColor grayColor];
        cell.contentView.backgroundColor = [UIColor grayColor];
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.detailTextLabel.textColor = [UIColor whiteColor];
    }
    cell.textLabel.text = [dataArray objectAtIndex:indexPath.row];
    if(indexPath.row == 0){
        if(loginState == 0){
            cell.detailTextLabel.text = @"未登录";
        }else{
            cell.detailTextLabel.text = @"已登录";
        }
    }else{
        cell.detailTextLabel.text = @"";
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [myTableView deselectRowAtIndexPath:indexPath animated:YES];
    if(indexPath.row == 0){
        [[MchInterfaceManager shareInstance] doLogin];
    }else if(indexPath.row == 1){
        MchPayInfo *orderInfo = [[MchPayInfo alloc] init];
        orderInfo.goodsName  = @"test001";
        orderInfo.goodsPrice = @"10";
        orderInfo.extendInfo = @"serverId=3|userId=1011s3p60896|productId=12";
        orderInfo.productId  = @"jinbicoin";//虚拟商品在APP Store中的ID
        [[MchInterfaceManager shareInstance] doPay:orderInfo];
    }else if (indexPath.row == 2){
        MchPayInfo *orderInfo = [[MchPayInfo alloc] init];
        orderInfo.goodsName  = @"test001";
        orderInfo.goodsPrice = @"10";
        orderInfo.extendInfo = @"serverId=3|userId=1011s3p60896|productId=12";
        orderInfo.productId  = @"jinbicoin";//虚拟商品在APP Store中的ID
        [[MchInterfaceManager shareInstance] doApplePay:orderInfo];
    }else if (indexPath.row == 3){
        [[MchInterfaceManager shareInstance] doLogout];
    }
}

- (void)mchInitResult:(BOOL)success{
    if(success){
        NSLog(@"初始化成功");
    }else{
        NSLog(@"初始化失败");
    }
}

- (void)mchLoginSuccessWithUid:(NSString *)user_id token:(NSString *)user_token{
    NSLog(@"user_id:%@ --- user_token:%@",user_id,user_token);
    [self logoutRefresh:1];
}

- (void)mchLoginFail{
    NSLog(@"登录失败");
}

- (void)mchDidLogout:(BOOL)success{
    NSLog(@"退出登录");
    [self logoutRefresh:0];
}

- (void)mchCreateOrderResult:(BOOL)success{
    if(success){
        NSLog(@"创建订单成功");
    }else{
        NSLog(@"创建订单失败");
    }
}

- (void)mchPayResult:(BOOL)success{
    if(success){
        NSLog(@"支付成功");
    }else{
        NSLog(@"支付失败");
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end



