//
//  main.m
//  MchInterfacDemo
//
//  Created by zhujin on 2017/7/3.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
