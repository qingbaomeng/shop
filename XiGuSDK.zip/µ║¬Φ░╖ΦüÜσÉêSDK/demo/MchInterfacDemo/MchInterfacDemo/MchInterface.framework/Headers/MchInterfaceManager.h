//
//  MchInterfaceManager.h
//  MchInterface
//
//  Created by zhujin on 2017/7/3.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class MchPayInfo;

@protocol MchInterfaceDelegate <NSObject>
@optional
- (void)mchInitResult:(BOOL)success;
- (void)mchLoginSuccessWithUid:(NSString *)user_id token:(NSString *)user_token;
- (void)mchLoginFail;
- (void)mchDidLogout:(BOOL)success;
- (void)mchCreateOrderResult:(BOOL)success;
- (void)mchPayResult:(BOOL)success;
@end


@interface MchInterfaceManager : NSObject
@property (nonatomic,weak) id <MchInterfaceDelegate>delegate;

+ (MchInterfaceManager *)shareInstance;
/**
 *  初始化
 */
- (void)doInit:(id<MchInterfaceDelegate>)target;
/**
 *  登录
 */
- (void)doLogin;
/**
 *  注销
 */
- (void)doLogout;
/**
 *  sdk支付
 */
- (void)doPay:(MchPayInfo *)sdkPayInfo;
- (void)doApplePay:(MchPayInfo *)sdkPayInfo;
/**
 *  溪谷sdk url回调方法
 */
- (void)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options;
- (void)application:(UIApplication *)application openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation;
@end






