//
//  MchInterface.h
//  MchInterface
//
//  Created by zhujin on 2017/6/30.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MchInterface.
FOUNDATION_EXPORT double MchInterfaceVersionNumber;

//! Project version string for MchInterface.
FOUNDATION_EXPORT const unsigned char MchInterfaceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MchInterface/PublicHeader.h>

#import <MchInterface/MchInterfaceManager.h>
#import <MchInterface/MchPayInfo.h>
