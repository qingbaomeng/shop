//
//  MchPayInfo.h
//  MchInterface
//
//  Created by zhujin on 2017/7/31.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MchPayInfo : NSObject
@property (nonatomic, strong) NSString  *goodsName;     //商品名
@property (nonatomic, strong) NSString  *goodsPrice;    //商品价格
@property (nonatomic, strong) NSString  *extendInfo;    //额外信息
@property (nonatomic, strong) NSString  *productId;     //应用内支付产品ID
@property (nonatomic, strong) NSString  *orderString;   //订单号
@end
