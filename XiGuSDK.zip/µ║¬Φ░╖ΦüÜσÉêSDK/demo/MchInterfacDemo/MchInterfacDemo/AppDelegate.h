//
//  AppDelegate.h
//  MchInterfacDemo
//
//  Created by zhujin on 2017/7/3.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

