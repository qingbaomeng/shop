//
//  HeePay.h
//  HeePay
//
//  Created by Jiangrx on 10/9/15.
//  Copyright © 2015 HuiYuan.NET. All rights reserved.
//

#import <UIKit/UIKit.h>
#import<HeePay/HYSDKManager.h>
#import<HeePay/HYPayReqModel.h>
#import<HeePay/HYPayResponModel.h>

//! Project version number for HeePay.
FOUNDATION_EXPORT double HeePayVersionNumber;

//! Project version string for HeePay.
FOUNDATION_EXPORT const unsigned char HeePayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HeePay/PublicHeader.h>


