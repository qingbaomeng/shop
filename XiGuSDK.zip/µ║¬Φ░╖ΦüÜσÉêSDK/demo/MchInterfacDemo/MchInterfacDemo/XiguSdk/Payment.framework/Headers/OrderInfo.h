//
//  OrderInfo.h
//  Payment
//
//  Created by 梦创 .
//  Copyright © 梦创. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OrderInfo : NSObject
@property (nonatomic, strong) NSString *goodsPrice;
@property (nonatomic, strong) NSString *goodsName;
@property (nonatomic, strong) NSString *goodsDesc;
@property (nonatomic, strong) NSString *productId;
@property (nonatomic, strong) NSString *extendInfo;//此字段会透传到游戏服务器，可拼接
@end


