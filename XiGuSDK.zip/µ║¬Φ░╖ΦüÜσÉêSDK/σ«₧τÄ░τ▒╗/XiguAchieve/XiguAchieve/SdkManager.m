//
//  SdkManager.m
//  MchInterface
//
//  Created by zhujin on 2017/8/2.
//  Copyright © 2017年 zhujin. All rights reserved.
//

#import "SdkManager.h"
#import <Payment/MCHApi.h>

static NSString *const KETINITNOTIFICATION    = @"initNotification";
static NSString *const KETLOGINNOTIFICATION   = @"loginNotification";
static NSString *const KETLOGOUTNOTIFICATION  = @"logoutNotification";
static NSString *const KETPAYNOTIFICATION     = @"payNotification";

@implementation SdkManager

+ (SdkManager *)shareInstance{
    static SdkManager *sdkManager = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        sdkManager = [[SdkManager alloc] init];
    });
    return sdkManager;
}

- (void)initSdkWithAppId:(NSString *)appId andAppKey:(NSString *)appKey{
    BOOL result = [[MCHApi sharedInstance] initApi:[UIApplication sharedApplication] didFinishLaunchingWithOptions:nil];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    if(result){
        [dic setValue:[NSNumber numberWithInteger:1] forKey:@"state"];
    }else{
        [dic setValue:[NSNumber numberWithInteger:0] forKey:@"state"];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:KETINITNOTIFICATION object:dic];
}

- (void)doLogin{
    [[MCHApi sharedInstance] addLoginView:^(NSDictionary *resultDict){
        NSString *loginRes = [NSString stringWithFormat:@"%@", [resultDict objectForKey:@"loginresult"]];
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        if([@"1" isEqualToString:loginRes]){
            [dic setValue:[NSNumber numberWithInteger:1] forKey:@"state"];
            [dic setValue:[resultDict objectForKey:@"userId"] forKey:@"userId"];
            [dic setValue:[resultDict objectForKey:@"token"] forKey:@"token"];
        }else if ([@"0" isEqualToString:loginRes]){
            [dic setValue:[NSNumber numberWithInteger:0] forKey:@"state"];
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:KETLOGINNOTIFICATION object:dic];
    }];
}

- (void)doLogout{
    [[MCHApi sharedInstance] exitLogin:^(NSDictionary *resultDict){
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        [dic setValue:[NSNumber numberWithInteger:1] forKey:@"state"];
        [[NSNotificationCenter defaultCenter] postNotificationName:KETLOGOUTNOTIFICATION object:dic];
    }];
}

- (void)doPay:(id)sdkPayInfo{
    OrderInfo *order = [[OrderInfo alloc] init];
    order.goodsName = [sdkPayInfo valueForKey:@"goodsName"];
    order.goodsDesc = @"";
    order.goodsPrice = [sdkPayInfo valueForKey:@"goodsPrice"];
    order.extendInfo = [sdkPayInfo valueForKey:@"extendInfo"];
    order.productId = [sdkPayInfo valueForKey:@"productId"];

    [[MCHApi sharedInstance] pay:order completionBlock:^(NSDictionary *resultDict){
        NSLog(@"[pay] resultDic = %@", resultDict);
        NSString *payRes = [NSString stringWithFormat:@"%@", [resultDict objectForKey:@"payresult"]];
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        if([@"1" isEqualToString:payRes]){
            [dic setValue:[NSNumber numberWithInteger:1] forKey:@"state"];
        }else if ([@"0" isEqualToString:payRes]){
            [dic setValue:[NSNumber numberWithInteger:0] forKey:@"state"];
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:KETPAYNOTIFICATION object:dic];
    }];
}

- (void)doApplePay:(id)sdkPayInfo{
    OrderInfo *order = [[OrderInfo alloc] init];
    order.goodsName = [sdkPayInfo valueForKey:@"goodsName"];
    order.goodsDesc = @"";
    order.goodsPrice = [sdkPayInfo valueForKey:@"goodsPrice"];
    order.extendInfo = [sdkPayInfo valueForKey:@"extendInfo"];
    order.productId = [sdkPayInfo valueForKey:@"productId"];
    
    [[MCHApi sharedInstance] appPay:order completionBlock:^(NSDictionary *resultDict){
        NSLog(@"[pay] resultDic = %@", resultDict);
        NSString *payRes = [NSString stringWithFormat:@"%@", [resultDict objectForKey:@"payresult"]];
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        if([@"1" isEqualToString:payRes]){
            [dic setValue:[NSNumber numberWithInteger:1] forKey:@"state"];
        }else if ([@"0" isEqualToString:payRes]){
            [dic setValue:[NSNumber numberWithInteger:0] forKey:@"state"];
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:KETPAYNOTIFICATION object:dic];
    }];
}

- (void)application:(id)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    [[MCHApi sharedInstance] application:annotation openURL:url sourceApplication:sourceApplication annotation:annotation];
}

- (void)application:(id)application openURL:(NSURL *)url options:(NSDictionary<NSString *,id> *)options{
    [[MCHApi sharedInstance] application:application openURL:url options:options];
}


@end




