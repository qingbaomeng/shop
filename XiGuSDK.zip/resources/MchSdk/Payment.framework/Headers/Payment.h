//
//  Payment.h
//  Payment
//
//  Created by 梦创 .
//  Copyright © 梦创. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MCHApi.h"
#import "OrderInfo.h"

//! Project version number for Payment.
FOUNDATION_EXPORT double PaymentVersionNumber;

//! Project version string for Payment.
FOUNDATION_EXPORT const unsigned char PaymentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Payment/PublicHeader.h>


