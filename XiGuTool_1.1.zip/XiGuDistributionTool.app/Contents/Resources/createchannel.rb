# !/usr/bin/ruby
# -*- coding: UTF-8 -*-

require 'rubygems'
gem "xcodeproj", ">=0.14.0"
# puts "打包环境正常"

require 'fileutils' #操作文件夹
require 'xcodeproj' #操作xcodeproj文件
require 'find'     #查找文件

# ruby createchannel.rb /Users/zhujinzhujin/Desktop/Projects/TestMixSdk/TestMixSdk.xcodeproj 1

class ChannelProject
	@createissuc = false

	def initialize(projectpath, channelid)
		@ori_xcodeproj_path = projectpath
		@channel_id = channelid
		# puts @ori_xcodeproj_path
	end

	def getProjectPath
		@cha_project_path 
	end

	def initData()
		@ori_pbxproj_path = File.join(@ori_xcodeproj_path, "project.pbxproj")
		@ori_xcodeproj_dir = File::dirname(@ori_xcodeproj_path)
		@ori_scheme_dir = File.join(@ori_xcodeproj_path, "xcuserdata")
		@ori_project_name = File.basename(@ori_xcodeproj_path,)
		@ori_project_name_pre = File.basename(@ori_xcodeproj_path, ".xcodeproj")

		@cha_project_name = @ori_project_name_pre + "_" + @channel_id + ".xcodeproj"
		@cha_project_path = File.join(@ori_xcodeproj_dir, @cha_project_name)
		@cha_pbxproj_path = File.join(@cha_project_path, "project.pbxproj")
		@cha_scheme_dir = File.join(@cha_project_path, "xcuserdata")
		# puts @ori_project_name
		# puts @cha_project_name
	end

	def updateSchemeFile(schemedir)
		schemefile = ""
		Find.find(schemedir) do |schemefilepath|
			if schemefilepath.include?".xcscheme"
				schemefile = schemefilepath
			end
		end

		if schemefile.empty?
			puts ".xcscheme不存在"
			return "0"
		end

		str = ""
	    File.open(schemefile, "r+"){|f|
	          f.each_line{|line|
	               str += line.gsub(File.basename(@ori_project_name), @cha_project_name)
	           }
	    }
	    # puts str
	   	File.open(schemefile, "w"){|f|
	        f.write str
	    }
	    return "1"
	end

	def createProjectFiles
		if(File::exist?(@cha_project_path))
			# FileUtils.remove_dir(destFile, force = false)
			# puts @cha_project_path
			FileUtils.rm_rf(@cha_project_path, :secure=>true)
		end

		Dir::mkdir(@cha_project_path, mode = 0777)
		FileUtils.cp(@ori_pbxproj_path, @cha_project_path)
		FileUtils.cp_r(@ori_scheme_dir, @cha_project_path)
		
		# if(File::exist?(@cha_project_path))
		# 	puts "渠道创建失败"
		# 	return
		# end
		
		unless File::exist?(@cha_project_path)
			puts "渠道创建失败"
			return
		end

		res = updateSchemeFile(@cha_scheme_dir)
		if "1".eql? res
			@createissuc = true
			#puts @cha_project_path
		else 
			puts "1"
		end
	end
end

# ----------------------------------------------------------------

class  AddFiles

	def initialize(projectpath, channelid, ipabundlerid)
		@ori_xcodeproj_path = projectpath
		@channel_id = channelid
		# puts @ori_xcodeproj_path
		@ipa_bundlerid = ipabundlerid
	end

	def plistHash
		@config_hash = Xcodeproj::Plist.read_from_path(@channel_plist_path)
	end

	def initData
		@project = Xcodeproj::Project.open(@ori_xcodeproj_path) 
		@target = @project.targets.first
		@nativetarget = @project.native_targets.first
		@group = @project.main_group.find_subpath(File.join('XiGuSdk'), true)
    	@group.set_source_tree('SOURCE_ROOT') # 把group的source_tree设置成 'SOURCE_ROOT'
		@project_dir = File::dirname(@ori_xcodeproj_path)
		@cha_file_path = File.join(@project_dir, 'XiGuSdk', @channel_id)
		@channel_plist_path = File.join(@cha_file_path, 'ConfigInfo.plist')
		# puts @cha_file_path
		plistHash()
	end

	# 添加系统framework
    def mch_add_system_framework(franames)
        # Array(franames).map do |name|
            # path_sdk_version = @target.sdk_version || Constants::LAST_KNOWN_IOS_SDK
            fra_group = @project.frameworks_group
            path = "Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS.sdk/System/Library/Frameworks/#{franames}.framework"
            unless ref = fra_group.find_file_by_path(path)
              ref = fra_group.new_file(path, :developer_dir)
            end

            unless @target.frameworks_build_phase.include?(ref)
                @target.frameworks_build_phase.add_file_reference(ref, true)
            end
        # end
    end
	# 添加系统library
    def mch_add_system_library(libnames)
        # Array(libnames).map do |name|
            # path_sdk_version = @target.sdk_version || Constants::LAST_KNOWN_IOS_SDK
            lib_group = @project.frameworks_group
            path = "Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS.sdk/usr/lib/#{libnames}.tbd"
            unless ref = lib_group.files.find { |ref| ref.path == path }
              ref = lib_group.new_file(path, :developer_dir)
            end

            unless @target.frameworks_build_phase.include? (ref)
                @target.frameworks_build_phase.add_file_reference(ref, true)
            end
        # end
    end

    # 获取framework 文件所在路径
    # def addFrameworkPath(frapath)
    # 	fra_real_path = File::dirname(frapath)
    # 	puts fra_real_path
    # end

    # 添加引用
    def addFileToTarget(filename)
        if filename != "." and filename != ".." and filename != ".DS_Store"
            # puts filename
            file_ref = @group.new_reference(filename)

            if filename.to_s.end_with?("pbobjc.m", "pbobjc.mm")
                @target.add_file_references(file_ref, '-fno-objc-arc')
            elsif filename.to_s.end_with?(".framework", ".a")
            	lib_real_path = File::dirname(filename)
            	
            	if filename.to_s.end_with?(".framework") and !"".eql?lib_real_path
            		config_list_fra = @target.build_configuration_list.get_setting("FRAMEWORK_SEARCH_PATHS")
            		old_fra_list = config_list_fra["Release"]
            		if !old_fra_list || "$(inherited)".eql?(old_fra_list)
            			old_fra_list = []
            			old_fra_list.push("$(inherited)")
            		end
            		old_fra_list.push(lib_real_path)
					@target.build_configuration_list.set_setting('FRAMEWORK_SEARCH_PATHS', old_fra_list)
            	end
            	if filename.to_s.end_with?(".a") and !"".eql?lib_real_path
            		config_list_lib = @target.build_configuration_list.get_setting("LIBRARY_SEARCH_PATHS")
            		old_lib_list = config_list_lib["Release"]
            		if !old_lib_list || "$(inherited)".eql?(old_lib_list)
            			old_lib_list = []
            			old_lib_list.push("$(inherited)")
            		end
            		old_lib_list.push(lib_real_path)
            		@target.build_configuration_list.set_setting('LIBRARY_SEARCH_PATHS', old_lib_list)
            	end
                @target.frameworks_build_phase.add_file_reference(file_ref, true)
            elsif filename.to_s.end_with?(".plist", ".bundle")
                @target.resources_build_phase.add_file_reference(file_ref, true)
            elsif filename.to_s.end_with?(".m", ".mm", ".cpp")
                @target.source_build_phase.add_file_reference(file_ref, true)
            # elsif (!filename.to_s.end_with?(".h"))
            #     @target.add_resources([file_ref])
            end
        end
    end

    # 添加group
	def createSubGroup(curfilepath)
	    	# @group = @project.main_group.find_subpath(File.join('XiGuSdk'), true)
	    	# /Users/zhujinzhujin/Desktop/GitProject/iOS/xigusticksdk/iossticksdk/MchGameDemo/XiGuSdk/13/resources/Wechat/libWeChatSDK.a
	    	temp_full_path = File::dirname(curfilepath)
	    	str_pos = -1
	    	sdk_group = ""
	    	if temp_full_path.include?("/implement/")
				str_pos = temp_full_path.index("/implement/")
	    	end

	    	if -1 == str_pos && temp_full_path.include?("/resources/")
	    		str_pos = temp_full_path.index("/resources/")
	    	end

	    	if -1 != str_pos
	    		sdk_group = "XiGuSdk/" + temp_full_path[str_pos + 11, temp_full_path.length]
	    	else 
	    		sdk_group = "XiGuSdk"
	    	end

	    	if !"".eql?(sdk_group)
	    		@group = @project.main_group.find_subpath(sdk_group, true) 
	    	end
    	
	end

	 # 查询所有文件
	def getAllRes(rootDir)
	        isfile = rootDir.to_s.end_with?(".framework", ".bundle")
	        if File.directory?(rootDir) and !isfile 
	            Dir.foreach(rootDir) do |filepath|
	                if filepath != "." and filepath != ".." and filepath != ".DS_Store"
	                    getAllRes(rootDir + "/" + filepath)
	                end
	            end
	        elsif 
	        	createSubGroup(rootDir)
	            addFileToTarget(rootDir)
	        end
	end

	def otherLinkerFlagStr
		otherlinkerString = ""
		if @config_hash.include?("otherlinkflag")
			temp_array = @config_hash["otherlinkflag"]
			Array(temp_array).map do |valuestr|
				otherlinkerString += valuestr
				otherlinkerString += " "
			end
		end
		return otherlinkerString
	end

	def enablebitcodeValue
		enablebitcode = ""
		if @config_hash.include?("enablebitcode")
			enablebitcode = @config_hash["enablebitcode"]
		end
		return enablebitcode
	end

	def setProjectParams
    	other_linker_flag_str = otherLinkerFlagStr()
		@target.build_configuration_list.set_setting('OTHER_LDFLAGS', other_linker_flag_str)

		enable_bitcode_str = enablebitcodeValue()
		@target.build_configuration_list.set_setting('ENABLE_BITCODE', enable_bitcode_str)

		info_plist_path = File.join("XiGuSdk", @channel_id, "Info.plist")
		@target.build_configuration_list.set_setting('INFOPLIST_FILE', info_plist_path)

		@target.build_configuration_list.set_setting('PRODUCT_BUNDLE_IDENTIFIER', @ipa_bundlerid)
	end

	def frameworkArray
		frameArray = Array.new
		if @config_hash.include?("systemFrameworks")
				frameArray = @config_hash["systemFrameworks"]
		end
		return frameArray
	end

	def mch_add_system_fraandlib()
		array_name = frameworkArray
		Array(array_name).map do |name|
			if (name.include?(".framework"))
				temp_name = name.gsub(".framework", "")
				mch_add_system_framework(temp_name)
			end

			if (name.include?(".tbd"))
				temp_name = name.gsub(".tbd", "")
				mch_add_system_library(temp_name)
			end
		end
	end

	def updateTargetConfig
		unless @target.platform_name.to_s == "ios"
			puts "不是ios工程"
			return
		end

		imp_path = File.join(@cha_file_path, "implement")
		if File::exist?(imp_path)
			getAllRes(imp_path)
		end
		res_path = File.join(@cha_file_path, "resources")
		if File::exist?(res_path)
			getAllRes(res_path)
		end
		mch_add_system_fraandlib()
    	setProjectParams()

  		@project.save()
	end

	def updatePlistFile
		infoDir = File::dirname(@ori_xcodeproj_path)
		info_plist_path = File.join(infoDir, "Info.plist")
		if (!File::exist?(info_plist_path))
			return
		end
		info_plist_dic = Xcodeproj::Plist.read_from_path(info_plist_path)

		hash_http = Hash.new
		hash_http["NSAllowsArbitraryLoads"] = true
		# h1 = {"NSAllowsArbitraryLoads"=>true}
		info_plist_dic.store("NSAppTransportSecurity", hash_http)

		# info_plist.each do |key,value|
		# 	puts "#{key} => #{value}" 
		# end

		Xcodeproj::Plist.write_to_path(info_plist_dic, info_plist_path)
	end
	
	def outMessage
		puts "0,#{@ori_xcodeproj_path}"
	end
end

create_project = ChannelProject.new(ARGV[0], ARGV[1])
create_project.initData()
create_project.createProjectFiles()
# puts create_project.getProjectPath()

addfiles = AddFiles.new(create_project.getProjectPath(), ARGV[1], ARGV[2])
# addfiles = AddFiles.new(ARGV[0])
addfiles.initData()
addfiles.updateTargetConfig()
# addfiles.updatePlistFile()
addfiles.outMessage()











