# !/usr/bin/ruby
# -*- coding: UTF-8 -*-

require 'rubygems'
gem "xcodeproj", ">=0.14.0"

require 'fileutils' #操作文件夹
require 'xcodeproj' #操作xcodeproj文件

# ruby ~/Desktop/Projects/TestMixSdk/analysisproject.rb /Users/zhujinzhujin/Desktop/GitProject/iOS/xigusticksdk/iossticksdk/MchGameDemo/MchInterfacDemo.xcodeproj

class Analysisproject 
	def initialize(projectpath)
		@project_path = projectpath
	end
	
	def startanalysis
		project = Xcodeproj::Project.open(@project_path) 
		pro_targets = project.targets

		target_str = ""
		pos_index = 0
		pro_targets.each do |t|
			if pos_index == 1
				target_str += ":"
			end
			target_str += t.name
			pos_index = 1
		end

		target_first = project.targets.first
		value_temp = target_first.build_configuration_list.get_setting("INFOPLIST_FILE")
		info_path = value_temp["Release"]
		puts "#{target_str},#{info_path}"
		return target_str, info_path
	end
	
end

analysis = Analysisproject.new(ARGV[0])
res = analysis.startanalysis()
